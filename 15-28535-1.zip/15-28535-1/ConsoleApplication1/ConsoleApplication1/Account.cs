﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Account
    {
        string accountName;
        string accountID;
        float accountBalance;

        public void SetAccountName(String accountName)
        {
            this.accountName = accountName;
            
        }
        public void SetAccountID(String accountID)
        {
            this.accountID = accountID;

        }
        public void SetAccountBalance(float accountBalance)
        {
            this.accountBalance = accountBalance;

        }

        public void Deposit(float amt)
        {
            this.accountBalance += amt;
        }

        public void Withdraw(float amt)
        {
            this.accountBalance -= amt;
        }

        public void ShowDetails()
        {
            Console.WriteLine("Account Name : {0}\nAccount ID : {1}\nBalance : {2}",accountName,accountID,accountBalance);
        }


    }
}
