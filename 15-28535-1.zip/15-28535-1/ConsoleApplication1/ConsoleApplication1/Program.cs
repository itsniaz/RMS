﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Output From Student Class");
            Student s = new Student();
            s.SetName("Niaz Ahmed");
            s.SetID("15-28535-1");
            s.SetCgpa(3.8f);
            s.SetDepartment("CSE");
            s.ShowInfo();

            Console.WriteLine("\nOutput From Triangle Class");
            Triangle t = new Triangle();
            t.SetX(3);
            t.SetY(3);
            t.SetZ(3);
            t.TestTriangle();

            Console.WriteLine("\nOutput From Account Class");
            Account ac = new Account();
            ac.SetAccountName("Niaz Ahmed");
            ac.SetAccountID("XYZ");
            ac.SetAccountBalance(5000.0f);
            ac.ShowDetails();

        }
    }
}
