﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Student
    {
        private string name;
        private string id;
        private string department;
        private float cgpa;

        public void SetName(string name)
        {
            this.name = name;
        }
        public void SetID(string id)
        {
            this.id = id;
        }
        public void SetDepartment(string department)
        {
            this.department = department;
        }
        public void SetCgpa(float cgpa)
        {
            this.cgpa = cgpa;
        }


        public string GetName()
        {
            return name;
        }
        public string GetID()
        {
            return id;
        }
        public float GetCgpa()
        {
            return cgpa;
        }
        public string GetDepartment()
        {
            return department;
        }

        public void ShowInfo()
        {
            Console.WriteLine("Name : {0}\nID : {1}\nCGPA : {2}\nDepartment : {3}",name,id,cgpa,department);

        }
    }
}
