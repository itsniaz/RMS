﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Triangle
    {
        int x;
        int y;
        int z;

        public void SetX(int x)
        {
            this.x = x;
        }
        public void SetY(int y)
        {
            this.y = y;
        }
        public void SetZ(int z)
        {
            this.z = z;
        }


        public int GetZ()
        {
            return z;
        }

        public int GetY()
        {
            return y;
        }
        public int GetX()
        {
            return x;
        }

        public void ShowInfo()
        {
            Console.WriteLine("X : {0}\nY : {1}\nZ : {2}");
        }

        public void TestTriangle()
        {
            if (x == y && x == z)
            {
                Console.WriteLine("Equilitarel");
            }
            else if (x == y || x == z || y == z)
            {
                Console.WriteLine("Iscosceles");
            }
            else
            {
                Console.WriteLine("Scalane");

            }
        }

        
    }
}
